// Fetch and display recipes
document.addEventListener("DOMContentLoaded", function () {
    const recipeContainer = document.getElementById("recipeContainer");
    const searchInput = document.getElementById("searchInput");
    const sortSelect = document.getElementById("sortSelect");
    const deleteAllBtn = document.getElementById("deleteAllBtn");

    function loadRecipes() {
        const recipes = JSON.parse(localStorage.getItem("recipes")) || [];
        recipeContainer.innerHTML = "";
        
        if (recipes.length === 0) {
            recipeContainer.innerHTML = "<p>No recipes found.</p>";
            return;
        }
        
        recipes.forEach((recipe, index) => {
            const recipeCard = document.createElement("div");
            recipeCard.classList.add("recipe-card");
            recipeCard.innerHTML = `
                <h3 onclick="viewRecipe(${index})">${recipe.title}</h3>
                <p>${recipe.description}</p>
                <button onclick="deleteRecipe(${index})">Delete</button>
            `;
            recipeContainer.appendChild(recipeCard);
        });
    }

    function deleteRecipe(index) {
        let recipes = JSON.parse(localStorage.getItem("recipes")) || [];
        recipes.splice(index, 1);
        localStorage.setItem("recipes", JSON.stringify(recipes));
        loadRecipes();
    }
    
    function viewRecipe(index) {
        localStorage.setItem("selectedRecipe", index);
        window.location.href = "recipedetails.html";
    }
    
    searchInput.addEventListener("input", function () {
        const query = searchInput.value.toLowerCase();
        document.querySelectorAll(".recipe-card").forEach(card => {
            const title = card.querySelector("h3").innerText.toLowerCase();
            card.style.display = title.includes(query) ? "block" : "none";
        });
    });

    deleteAllBtn.addEventListener("click", function () {
        if (confirm("Are you sure you want to delete all recipes?")) {
            localStorage.removeItem("recipes");
            loadRecipes();
        }
    });
    
    loadRecipes();
});
