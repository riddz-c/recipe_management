// Open Modal on "Add" Button Click
const addEditBtn = document.getElementById('addEditBtn');
const modal = document.getElementById('modal');
const closeBtn = document.querySelector('.close-btn');
const recipeForm = document.getElementById('recipeForm');

addEditBtn.addEventListener('click', () => {
    modal.style.display = 'block';
});

// Close Modal on "X" Click
closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
});

// Close Modal on Outside Click
window.addEventListener('click', (event) => {
    if (event.target === modal) {
        modal.style.display = 'none';
    }
});

// Save Recipe to `add.html`
recipeForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const title = document.getElementById('title').value;
    const description = document.getElementById('description').value;
    const ingredients = document.getElementById('ingredients').value;
    const steps = document.getElementById('steps').value;

    const recipeData = {
        title,
        description,
        ingredients,
        steps
    };

    // Store data in local storage
    let recipes = JSON.parse(localStorage.getItem('recipes')) || [];
    recipes.push(recipeData);
    localStorage.setItem('recipes', JSON.stringify(recipes));

    // Redirect to add.html
    window.location.href = 'add.html';
});
